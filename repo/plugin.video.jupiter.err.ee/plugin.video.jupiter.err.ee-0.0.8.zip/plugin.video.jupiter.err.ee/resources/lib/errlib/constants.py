
ERR_API_VERSION = 'v2'
ERR_API_BASEURL = 'https://services.err.ee/api/'
USER_AGENT = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1'
DEFAULT_VERTICAL_PHOTO = ''
EMPTYSTRING = ''
